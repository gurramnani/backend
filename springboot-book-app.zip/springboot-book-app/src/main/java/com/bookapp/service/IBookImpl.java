package com.bookapp.service;

import com.bookapp.exception.BookNotFoundException;
import com.bookapp.model.Book;
import com.bookapp.util.BookUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class IBookImpl implements IBook{

    @Autowired
    private BookUtil bookUtil;

    @Override
    public List<Book> getByAuthor(String author) {
        List<Book> books = bookUtil.getAllBooks().stream()
                .filter(book -> book.getAuthor().equals(author))
                .collect(Collectors.toList());

        if (books.isEmpty()) {
            throw new BookNotFoundException("Book with the author is not available");
        }
        return books;
    }


    @Override
    public List<Book> getByCategory(String category) {
        List<Book> books = bookUtil.getAllBooks().stream()
                .filter(book -> book.getCategory().equals(category))
                .collect(Collectors.toList());

        if (books.isEmpty()) {
            throw new BookNotFoundException("Book with the author is not available");
        }
        return books;
    }


    @Override
    public List<Book> getByLesserPrice(String author, double price) {
        List<Book> books = bookUtil.getAllBooks().stream()
                .filter(book -> book.getAuthor().equals(author) && book.getPrice()<price)
                .collect(Collectors.toList());

        if (books.isEmpty()) {
            throw new BookNotFoundException("Book with the author is not available");
        }
        return books;
    }

    @Override
    public List<Book> getByTitle(String choice) {
        List<Book> books = bookUtil.getAllBooks().stream()
                .filter(book -> book.getTitle().startsWith(choice))
                .collect(Collectors.toList());

        if (books.isEmpty()) {
            throw new BookNotFoundException("Book with the author is not available");
        }
        return books;
    }

    @Override
    public Book getById(int bookId) {
        return bookUtil.getAllBooks().stream()
                .filter(book -> book.getBookId() == bookId)
                .findFirst()
                .orElseThrow(() -> new BookNotFoundException("Book with ID " + bookId + " not found"));
    }


    @Override
    public List<Book> getAll() {
        return bookUtil.getAllBooks();
    }
}
