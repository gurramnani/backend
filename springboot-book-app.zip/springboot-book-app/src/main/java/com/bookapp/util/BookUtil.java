package com.bookapp.util;

import com.bookapp.model.Book;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class BookUtil {
    public List<Book> getAllBooks(){
      return Arrays.asList(
              new Book("Java",1,"Kathy","Tech",907.45),
              new Book("Spring",3,"John","Tech",9027.45),
              new Book("Java for dummies",5,"Kathy John","Tech",807.45),
              new Book("Springboot",2,"Kal","Tech",87.45),
              new Book("MySql",8,"Kathfi","Tech",90.45)

      );
    }
}
