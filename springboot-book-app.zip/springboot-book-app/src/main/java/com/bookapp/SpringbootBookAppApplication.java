package com.bookapp;

import com.bookapp.model.Book;
import com.bookapp.service.IBook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootBookAppApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootBookAppApplication.class, args);
	}

	@Autowired
	private IBook iBook;

	@Override
	public void run(String... args) throws Exception {
    iBook.getAll().forEach(System.out::println);
		System.out.println("Author");
		iBook.getByAuthor("Kathy").forEach(System.out::println);

		System.out.println("Title");
		iBook.getByTitle("J").forEach(System.out::println);

		System.out.println("Category");
		iBook.getByCategory("Tech").forEach(System.out::println);

		System.out.println("Lesser Price");
		iBook.getByLesserPrice("John",9028.45).forEach(System.out::println);

		System.out.println("Id");
		Book b = iBook.getById(3);
		System.out.println(b);
	}
}
