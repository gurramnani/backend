package com.restapi.demo.service;

import org.springframework.stereotype.Service;

@Service
public class MobileInternalImplementation implements MobileService {

private final MobileServiceImplementation mobileServiceImplementation;

public MobileInternalImplementation(MobileServiceImplementation mobileServiceImplementation){
    this.mobileServiceImplementation=mobileServiceImplementation;
}
}
