package com.restapi.demo.service;


public interface MobileService {
}
