package com.restapi.demo.service;

import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class MobileServiceImplementation implements MobileService {

    private final MobileInternalImplementation mobileInternalImplementation;

    /*
    In production, circular dependencies should be avoided by redesigning
     the application, typically by introducing a third service(CommonService example) or restructuring
     responsibilities. Using @Lazy is only a temporary workaround.
     */
    public MobileServiceImplementation(@Lazy MobileInternalImplementation mobileInternalImplementation) {
        this.mobileInternalImplementation = mobileInternalImplementation;
    }
}
