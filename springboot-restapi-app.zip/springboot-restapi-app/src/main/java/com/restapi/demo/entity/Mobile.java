package com.restapi.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import org.springframework.core.SpringVersion;

@Entity
public class Mobile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int emiNumber;
    private String model;
    private double price;
    private String core;

    public Mobile() {
        super();
    }

    public Mobile(int emiNumber, String model, double price, String core) {
        this.emiNumber = emiNumber;
        this.model = model;
        this.price = price;
        this.core = core;
    }

    public int getEmiNumber() {
        return emiNumber;
    }

    public void setEmiNumber(int emiNumber) {
        this.emiNumber = emiNumber;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getCore() {
        return core;
    }

    public void setCore(String core) {
        this.core = core;
    }

    @Override
    public String toString() {
        return "Mobile{" +
                "emiNumber=" + emiNumber +
                ", model='" + model + '\'' +
                ", price=" + price +
                ", core='" + core + '\'' +
                '}';
    }
}
