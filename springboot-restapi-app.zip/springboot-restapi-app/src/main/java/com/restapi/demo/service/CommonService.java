package com.restapi.demo.service;

import org.springframework.stereotype.Service;

@Service
public class CommonService {
    private final MobileInternalImplementation m;
    private final MobileServiceImplementation m1;

    public CommonService(MobileInternalImplementation m, MobileServiceImplementation m1){
        this.m=m;
        this.m1=m1;
    }
}
