package com.restapi.demo.controller;

import com.restapi.demo.service.MobileService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Qualifier
public class MobileController {

    private final MobileService mobileService;
    /*
    Field injection

    @Autowired
    MobileService mobileService;
    *Advantage: Easy to use and maintain
    DisAdvantage: not supported by immutable objects as variable as final, may throws NPE


    Setter Injection
    @Autowired
    public void setMobileService(MobileService mobileService){
        this.mobileService = mobileService;
    }

        DisAdvantage: not supported by immutable objects as variable as final, may throws NPE



*/



//Constructor Injection: Recomended way of injection, when multiple classes need to be injected then we can pass multiple args in the parameters of contructor
    //Dependency are Mandatory, want immutable objects, for production code
    /*
        Multiple Implementations: Use Constructor Injection + @Qualifier
        Need Default Bean: use @Primary at required service class

        When both @Qualifier and @Primary are present, @Qualifier takes precedence because
         it explicitly specifies which bean to inject, while @Primary is only a default fallback.
     */
    public MobileController(@Qualifier("mobileInternalImplementation") MobileService mobileService){
        this.mobileService=mobileService;
    }
}
