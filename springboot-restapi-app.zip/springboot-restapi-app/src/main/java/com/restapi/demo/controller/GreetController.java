package com.restapi.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class GreetController {

    // A REST API. we can call this by using http://localhost:8080/greet

    @GetMapping("/greet")
    public String greetMessage(){
        //calls the method of service and will return the data to the calling client
        //return a resource - as a response
        return "Have a great day";
    }

    //http://localhost:8080/welcome?username=Nani&city=Kurnool
// if the data comes from a form use @RequestParam
    @GetMapping("welcome")
    public String welcomeUser(@RequestParam("username") String user,@RequestParam("city") String city){
        return "Welcome "+user+" from "+city;
    }

    // http://localhost:8080/showbooks/tech
   // http://localhost:8080/showbooks/selfhelp
    // if the data comes from the url use @PathVariable to retrive it

    @GetMapping("/showbooks/{category}")
    public List<String> showBooks(@PathVariable("category") String type){
        if(type.equals("tech"))
            return Arrays.asList("Java","Spring");
        return Arrays.asList("Secret","LeaderShip");
    }
}
