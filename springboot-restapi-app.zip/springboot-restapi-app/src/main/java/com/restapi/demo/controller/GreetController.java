package com.restapi.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
public class GreetController {

    // A REST API. we can call this by using http://localhost:8080/greet

    @GetMapping("/greet")
    public String greetMessage(){
        //calls the method of service and will return the data to the calling client
        //return a resource - as a response
        return "Have a great day";
    }

    /*
    @RequestParam
     Definition: Extracts values from the query string of the URL.
     Syntax in URL: ?key=value
     Use case: For optional data, filters, or search parameters.
     Use @RequestParam when the parameter modifies or filters the request.
     * When you’re searching, filtering, or getting multiple resources.

      http://localhost:8080/welcome?username=Nani&city=Kurnool

      if the data comes from a form use @RequestParam
   */
    @GetMapping("welcome")
    public String welcomeUser(@RequestParam("username") String user,@RequestParam("city") String city){
        return "Welcome "+user+" from "+city;
    }

    @GetMapping("/books")
    public String getBooks(@RequestParam(defaultValue = "Unknown") String author) {
        return "Books by author: " + author;
    }
   /*
     Here, author is required by default.
     If you call /books without ?author=John, you’ll get:
     ❌ 400 Bad Request – Required request parameter 'author' is not present
  */

    @GetMapping("/booksByAuthor")
    public String getBooksByAuthor(@RequestParam(required = false) String author) {
        if (author != null) {
            return "Books by author: " + author;
        } else {
            return "All books";
        }
    }
    /*
      Now author is optional.
      You can call:
       /books?author=John 👉 returns books by John
       /books 👉 returns all books (no error)
     */

    @GetMapping("/booksByAuthors")
    public String getBooksByAuthors(@RequestParam(defaultValue = "Unknown") String author) {
        return "Books by author: " + author;
    }
    /*
      /books?author=John 👉 Books by author: John
      /books 👉 Books by author: Unknown
     */


  /*
    http://localhost:8080/showbooks/tech
    http://localhost:8080/showbooks/selfhelp
    if the data comes from the url use @PathVariable to retrive it
  */


    @GetMapping("/showbooks/{category}")
    public List<String> showBooks(@PathVariable("category") String type){
        if(type.equals("1"))
            return Arrays.asList("Java","Spring");
        return Arrays.asList("Secret","LeaderShip");
    }


    /*
🔹 @PathVariable
   Definition: Extracts values from the URI path itself.
   Syntax in URL: /value
   Use case: For resource identification (ID, username, etc.).

   Resource identity → @PathVariable

     */
}
