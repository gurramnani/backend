package com.restapi.di.conditionalonproperty;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DBConnection {

    //Marking required = false will make the application to run smoothly even if the bean is not injected and makes the bean as null
    @Autowired(required = false)
    NoSqlConnection noSqlConnection;

    @Autowired(required = false)
    SqlConnection sqlConnection;

    @PostConstruct
    public void init() {
        System.out.println("DB Connection init");
        System.out.println("Nosql Connection "+noSqlConnection);
        System.out.println("SqlConnection "+sqlConnection);
    }



}
