package com.restapi.di.conditionalonproperty;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(
        prefix="nosqlconnection",
        value="enabled",
        havingValue = "true",
        matchIfMissing = false
)
public class NoSqlConnection {
    public NoSqlConnection(){
        System.out.println("NoSqlConnection Created");
    }
}
