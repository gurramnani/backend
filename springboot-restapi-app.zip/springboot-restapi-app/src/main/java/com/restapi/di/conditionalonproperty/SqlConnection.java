package com.restapi.di.conditionalonproperty;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(
        prefix="sqlconnection",
        value="enabled",
        havingValue = "true",
        matchIfMissing = false
)
/*
   if sqlconnection.enabled=true this value present in application.properties same as mentioned in @ConditionalOnProperty then create the bean
     if the sqlconnection.enabled=true is not present in application.properties then it won't create a bean

     if the configuration is missing like prefix, value then it will check the
      matchIfMissing value if it's false, it won't inject the bean and if it's true, then it will inject the bean
 */
public class SqlConnection {
    public SqlConnection(){
        System.out.println("SQLConnection Created");
    }
}
