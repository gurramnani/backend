package com.security.config;

import com.security.service.CustomeUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    //says application to use basic authentication:
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {


        http.csrf(AbstractHttpConfigurer::disable).
                authorizeHttpRequests(
                        // where you define authorization rules.it tells Spring Security which endpoints are accessible to whom.
                auth->auth.requestMatchers("/h2-console").permitAll().
                // request matching with h2-console will be permitted without any authentication.other than this all requests will be authenticated
                                      anyRequest().authenticated()).
                //Applies to all other requests (not matched above), authenticated() means the user must be logged in (authenticated) to access.
                httpBasic(withDefaults());
        //Enables Basic Authentication scheme.
        return http.build();
    }
/*
User requests /h2-console → allowed directly (no login).
User requests /anythingElse:
If no credentials → Spring Security responds with 401 Unauthorized.
If credentials given → Spring checks with configured UserDetailsService (or default user).
If valid → request is allowed.
If invalid → 403 Forbidden.
 */
    @Bean
    public UserDetailsService userDetailsService(){
        return new CustomeUserDetailsService();
    }

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }


    @Bean
    public AuthenticationManager authenticationManager(UserDetailsService userDetailsService,PasswordEncoder passwordEncoder){

        DaoAuthenticationProvider daoAuthenticationProvider = new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(userDetailsService);
        daoAuthenticationProvider.setPasswordEncoder(passwordEncoder);

        return new ProviderManager(daoAuthenticationProvider);
    }

}
