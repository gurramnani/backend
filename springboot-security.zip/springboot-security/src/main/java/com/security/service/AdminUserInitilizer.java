package com.security.service;

import com.security.entity.Users;
import com.security.repository.UserDetailsRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class AdminUserInitilizer {
    public CommandLineRunner createAdminUser(UserDetailsRepository userDetailsRepository, PasswordEncoder passwordEncoder){
        return args -> {
            if(userDetailsRepository.findByUserName("admin").isEmpty()){
                Users users = new Users();
                users.setUsername("admin");
                users.setPassword(passwordEncoder.encode("admin@123"));
                users.setRole("ROLE_ADMIN");
                userDetailsRepository.save(users);
                System.out.println("default admin user created");
            }
        };
    }
}
