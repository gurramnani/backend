package com.security.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController("/")
public class GreetController {
    @GetMapping("/greet/{username}")
    public String getMessage(@PathVariable String username) {
        return "Greet Day " + username;
    }

    @GetMapping("/greet/showbooks")
    public List<String> getMessage() {
        return List.of("Java", "Angural");
    }
}