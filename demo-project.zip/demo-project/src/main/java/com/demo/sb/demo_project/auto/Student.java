package com.demo.sb.demo_project.auto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Student {


    @Autowired
    @Qualifier("frontEnd")            //Autowiring by type
    private Course course;


    @Autowired
    private Course backend;           //Autowiring by name

    private Course cloudA;

    public Student(@Qualifier("cloud") Course cloudA) {
        this.cloudA = cloudA;                              //Autowiring by constructor
    }

    public List<String> showCourses(String s){
        if(s.equals("frontEnd"))
            return course.getAllCourses();
        if(s.equals("cloud"))
            return cloudA.getAllCourses();
        if(s.equals("backend"))
            return  backend.getAllCourses();
        return List.of("No Elements Available");
    }
}
