package com.demo.sb.demo_project.auto;
import java.util.List;


public interface Course {
    List<String> getAllCourses();
}