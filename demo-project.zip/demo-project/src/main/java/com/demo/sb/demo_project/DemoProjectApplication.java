package com.demo.sb.demo_project;

import com.demo.sb.demo_project.auto.Student;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoProjectApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(DemoProjectApplication.class, args);
	}
	private Student student;

	@Autowired
	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public void run(String... args) throws Exception {
        student.showCourses("frontEnd").forEach(System.out::println);
		student.showCourses("backend").forEach(System.out::println);
		student.showCourses("cloud").forEach(System.out::println);
	}
}
