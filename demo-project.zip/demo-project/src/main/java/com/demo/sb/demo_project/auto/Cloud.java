package com.demo.sb.demo_project.auto;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class Cloud implements Course{

    @Override
    public List<String> getAllCourses() {
        return List.of("AWS","AZURE");
    }
}
