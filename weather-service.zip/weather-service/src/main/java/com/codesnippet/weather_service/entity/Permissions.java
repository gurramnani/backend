package com.codesnippet.weather_service.entity;

public enum Permissions {
    WEATHER_READ,
    WEATHER_WRITE,
    WEATHER_DELETE
}
