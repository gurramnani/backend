package com.javaconfig.demo;

import com.javaconfig.demo.javabased.Address;
import com.javaconfig.demo.javabased.Employee;
import com.javaconfig.demo.jbased.Electronics;
import com.javaconfig.demo.jbased.HomeAppliances;
import com.javaconfig.demo.jbased.Product;
import com.javaconfig.demo.jbased.Sports;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration  //IOC container will look for bean definations from this annotated class
public class AppConfig {

    //bean name is same as the method name
    @Bean
    public Employee getEmployee(){
        //Employee employee = new Employee();
        //employee.setAddress(getAddress());
        return new Employee();
    }

    @Bean
    public Address getAddress(){
        return new Address();
    }

    @Bean
    public HomeAppliances homeAppliances(){
        return new HomeAppliances();
    }

    @Bean @Primary
    public Sports sports(){
        return new Sports();
    }

    @Bean
    public Electronics electronics(){
        return new Electronics();
    }

    @Bean
    public Product product(){
        return new Product();
    }

}
