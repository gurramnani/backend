package com.javaconfig.demo.jbased;

import java.util.List;

public interface Category {
    List<String> getAllProducts();
}
