package com.javaconfig.demo.jbased;

import java.util.List;

public class HomeAppliances implements Category{
    @Override
    public List<String> getAllProducts() {
        return List.of("Stove","Washing machine","Fridge");
    }
}
