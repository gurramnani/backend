package com.javaconfig.demo.jbased;

import java.util.List;

public class Sports implements Category{
    @Override
    public List<String> getAllProducts() {
        return List.of("Bat","Ball","Gloves");
    }
}
