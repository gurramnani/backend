package com.javaconfig.demo;

import com.javaconfig.demo.javabased.Employee;
import com.javaconfig.demo.jbased.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJavaconfigAppApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJavaconfigAppApplication.class, args);
	}

	@Autowired
    private Employee employee;

	@Autowired
	private Product product;

	@Override
	public void run(String... args) throws Exception {
	employee.greetEmp();
	product.showProducts();
	}
}
