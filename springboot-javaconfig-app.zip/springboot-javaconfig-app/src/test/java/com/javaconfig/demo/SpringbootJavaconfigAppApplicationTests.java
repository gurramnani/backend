package com.javaconfig.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootJavaconfigAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
